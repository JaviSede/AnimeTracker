//
//  UserModel.swift
//  AnimeTracker
//
//  Created by Javi Sedeño on 28/3/25.
//  Updated by Manus on 30/4/25 to remove embedded AnimeStats model.
//

import Foundation
import SwiftData

@Model
final class UserModel {
    @Attribute(.unique) var id: String // Ensure ID is unique
    var username: String
    @Attribute(.unique) var email: String // Ensure email is unique
    var profileImageUrl: String?
    var bio: String?
    var joinDate: Date
    var password: String // WARNING: In production, use secure hashing and storage methods

    // Relationships
    // Cascade ensures stats are deleted if user is deleted
    // Inverse relationship helps SwiftData manage the connection
    @Relationship(deleteRule: .cascade, inverse: \AnimeStats.user)
    var stats: AnimeStats?

    // Cascade ensures saved animes are deleted if user is deleted
    @Relationship(deleteRule: .cascade, inverse: \SavedAnimeModel.user)
    var savedAnimes: [SavedAnimeModel] = []

    init(id: String = UUID().uuidString,
         username: String,
         email: String,
         profileImageUrl: String? = nil,
         bio: String? = nil,
         password: String) {
        self.id = id
        self.username = username
        self.email = email
        self.profileImageUrl = profileImageUrl
        self.bio = bio
        self.joinDate = Date()
        self.password = password
        // Initializing stats here can be problematic with SwiftData relationships
        // It's better to create and assign stats during registration or lazily
        // self.stats = AnimeStats() // Removed initialization from here
        self.savedAnimes = []
    }
}

// AnimeStats class has been moved to its own file: AnimeStats.swift

