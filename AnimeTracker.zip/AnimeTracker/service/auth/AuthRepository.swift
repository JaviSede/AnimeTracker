//
//  AuthRepository.swift
//  AnimeTracker
//

import Foundation
import SwiftData
import CryptoKit

// Protocolo para el repositorio de autenticación
protocol AuthRepositoryProtocol {
    func login(email: String, password: String) async throws -> UserModel
    func register(username: String, email: String, password: String) async throws -> UserModel
    func getCurrentUser() async throws -> UserModel?
    func logout() async
    func updateCurrentUserID(_ userID: String?)
}

class AuthRepository: AuthRepositoryProtocol {
    private let modelContext: ModelContext
    private let userDefaultsKey = "currentUserLoginID"
    private let keychainService = "com.animetracker.auth"
    
    init(modelContext: ModelContext) {
        self.modelContext = modelContext
    }
    
    func login(email: String, password: String) async throws -> UserModel {
        let predicate = #Predicate<UserModel> { $0.email == email }
        let descriptor = FetchDescriptor<UserModel>(predicate: predicate)
        
        let users = try modelContext.fetch(descriptor)
        guard let user = users.first else {
            throw AuthError.invalidCredentials
        }
        
        // Verificar contraseña con hash seguro
        guard try verifyPassword(password, hashedPassword: user.password) else {
            throw AuthError.invalidCredentials
        }
        
        // Guardar ID de usuario en UserDefaults
        updateCurrentUserID(user.id)
        
        return user
    }
    
    func register(username: String, email: String, password: String) async throws -> UserModel {
        // Verificar si el email ya existe
        let predicate = #Predicate<UserModel> { $0.email == email }
        let descriptor = FetchDescriptor<UserModel>(predicate: predicate)
        let existingUsers = try modelContext.fetch(descriptor)
        
        if !existingUsers.isEmpty {
            throw AuthError.emailAlreadyExists
        }
        
        // Crear hash de la contraseña
        let hashedPassword = try hashPassword(password)
        
        // Crear nuevo usuario
        let newUser = UserModel(
            username: username,
            email: email,
            password: hashedPassword
        )
        
        // Crear estadísticas
        let stats = AnimeStats()
        newUser.stats = stats
        stats.user = newUser
        
        // Guardar en la base de datos
        modelContext.insert(newUser)
        modelContext.insert(stats)
        
        do {
            try modelContext.save()
            
            // Guardar ID de usuario en UserDefaults
            updateCurrentUserID(newUser.id)
            
            return newUser
        } catch {
            modelContext.rollback()
            throw AuthError.registrationFailed(error.localizedDescription)
        }
    }
    
    func getCurrentUser() async throws -> UserModel? {
        guard let userID = UserDefaults.standard.string(forKey: userDefaultsKey) else {
            return nil
        }
        
        let predicate = #Predicate<UserModel> { $0.id == userID }
        let descriptor = FetchDescriptor<UserModel>(predicate: predicate)
        
        let users = try modelContext.fetch(descriptor)
        return users.first
    }
    
    func logout() async {
        updateCurrentUserID(nil)
    }
    
    func updateCurrentUserID(_ userID: String?) {
        if let userID = userID {
            UserDefaults.standard.set(userID, forKey: userDefaultsKey)
        } else {
            UserDefaults.standard.removeObject(forKey: userDefaultsKey)
        }
    }
    
    // MARK: - Métodos de seguridad para contraseñas
    
    private func hashPassword(_ password: String) throws -> String {
        let salt = generateSalt()
        let saltedPassword = password + salt
        
        guard let data = saltedPassword.data(using: .utf8) else {
            throw AuthError.hashingFailed
        }
        
        let hashed = SHA256.hash(data: data)
        let hashString = hashed.compactMap { String(format: "%02x", $0) }.joined()
        
        // Formato: hash:salt
        return "\(hashString):\(salt)"
    }
    
    private func verifyPassword(_ password: String, hashedPassword: String) throws -> Bool {
        let components = hashedPassword.split(separator: ":")
        guard components.count == 2 else {
            throw AuthError.invalidPasswordFormat
        }
        
        let salt = String(components[1])
        let saltedPassword = password + salt
        
        guard let data = saltedPassword.data(using: .utf8) else {
            throw AuthError.hashingFailed
        }
        
        let hashed = SHA256.hash(data: data)
        let hashString = hashed.compactMap { String(format: "%02x", $0) }.joined()
        
        return hashString == String(components[0])
    }
    
    private func generateSalt(length: Int = 16) -> String {
        let characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return String((0..<length).map { _ in characters.randomElement()! })
    }
}

// Errores específicos de autenticación
enum AuthError: Error, LocalizedError {
    case invalidCredentials
    case emailAlreadyExists
    case registrationFailed(String)
    case userNotFound
    case hashingFailed
    case invalidPasswordFormat
    
    var errorDescription: String? {
        switch self {
        case .invalidCredentials:
            return "Email o contraseña incorrectos"
        case .emailAlreadyExists:
            return "Este email ya está registrado"
        case .registrationFailed(let reason):
            return "Error al registrar: \(reason)"
        case .userNotFound:
            return "Usuario no encontrado"
        case .hashingFailed:
            return "Error al procesar la contraseña"
        case .invalidPasswordFormat:
            return "Formato de contraseña inválido"
        }
    }
}