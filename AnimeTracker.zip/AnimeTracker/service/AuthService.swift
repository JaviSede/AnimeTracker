//
//  AuthService.swift
//  AnimeTracker
//

import Foundation
import SwiftUI
import SwiftData
import Combine

class AuthService: ObservableObject {
    // Estado publicado
    @Published var currentUser: UserModel?
    @Published var isAuthenticated = false
    @Published var isLoading = false
    @Published var error: String?
    
    // Dependencias
    private var repository: AuthRepositoryProtocol?
    private var cancellables = Set<AnyCancellable>()
    
    // Validadores
    private let credentialsValidator = CredentialsValidator()
    private let registrationValidator = RegistrationValidator()
    
    init() {}
    
    func setModelContext(_ context: ModelContext) {
        self.repository = AuthRepository(modelContext: context)
        loadCurrentUser()
    }
    
    func loadCurrentUser() {
        guard let repository = repository else {
            print("AuthService: Repository not available yet for loading user.")
            return
        }
        
        isLoading = true
        error = nil
        
        Task {
            do {
                let user = try await repository.getCurrentUser()
                await MainActor.run {
                    self.currentUser = user
                    self.isAuthenticated = user != nil
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.error = error.localizedDescription
                    self.isAuthenticated = false
                    self.isLoading = false
                }
            }
        }
    }
    
    func login(email: String, password: String) {
        guard let repository = repository else {
            self.error = "Servicio no disponible. Intenta más tarde."
            return
        }
        
        // Validar credenciales
        let credentials = Credentials(email: email, password: password)
        let validationResult = credentialsValidator.validate(credentials)
        
        if !validationResult.isValid {
            self.error = validationResult.errors.first?.localizedDescription
            return
        }
        
        isLoading = true
        error = nil
        
        Task {
            do {
                let user = try await repository.login(email: email, password: password)
                await MainActor.run {
                    self.currentUser = user
                    self.isAuthenticated = true
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.error = error.localizedDescription
                    self.isAuthenticated = false
                    self.isLoading = false
                }
            }
        }
    }
    
    func register(username: String, email: String, password: String, confirmPassword: String = "") {
        guard let repository = repository else {
            self.error = "Servicio no disponible. Intenta más tarde."
            return
        }
        
        // Validar datos de registro
        let registrationData = RegistrationData(
            username: username,
            email: email,
            password: password,
            confirmPassword: confirmPassword.isEmpty ? password : confirmPassword
        )
        
        let validationResult = registrationValidator.validate(registrationData)
        
        if !validationResult.isValid {
            self.error = validationResult.errors.first?.localizedDescription
            return
        }
        
        isLoading = true
        error = nil
        
        Task {
            do {
                let user = try await repository.register(
                    username: username,
                    email: email,
                    password: password
                )
                
                await MainActor.run {
                    self.currentUser = user
                    self.isAuthenticated = true
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.error = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
    
    func logout() {
        guard let repository = repository else {
            return
        }
        
        Task {
            await repository.logout()
            await MainActor.run {
                self.currentUser = nil
                self.isAuthenticated = false
            }
        }
    }
    
    // Otros métodos como updateProfile, etc.
}