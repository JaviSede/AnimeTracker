//
//  AuthService.swift
//  AnimeTracker
//

import Foundation
import SwiftUI
import SwiftData
import Combine

class AuthService: ObservableObject {
    // Estado publicado
    @Published var isAuthenticated = false
    @Published var isLoading = false
    @Published var error: String?

    
    // Dependencias
    private var repository: AuthRepositoryProtocol?
    private var cancellables = Set<AnyCancellable>()
    
    // Validadores
    private let credentialsValidator = CredentialsValidator()
    private let registrationValidator = RegistrationValidator()
    
    init() {}
    
    func setModelContext(_ context: ModelContext) {
        self.repository = AuthRepository(modelContext: context)
        loadCurrentUser()
    }
    
    func loadCurrentUser() {
        guard let repository = repository else {
            print("AuthService: Repository not available yet for loading user.")
            return
        }
        
        isLoading = true
        error = nil
        
        Task {
            do {
                let user = try await repository.getCurrentUser()
                await MainActor.run {
                    self.currentUser = user
                    self.isAuthenticated = user != nil
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    // Mostrar error específico de Keychain si es posible
                    if let authError = error as? AuthError, case .keychainError(let reason) = authError {
                        self.error = "Keychain Error: \(reason)"
                    } else {
                        self.error = "Failed to load user: \(error.localizedDescription)"
                    }
                    self.isAuthenticated = false
                    self.isLoading = false
                }
            }
        }
    }
    
    func login(email: String, password: String) {
        guard let repository = repository else {
            self.error = "Servicio no disponible. Intenta más tarde."
            return
        }
        
        // Validar credenciales
        let credentials = Credentials(email: email, password: password)
        let validationResult = credentialsValidator.validate(credentials)
        
        if !validationResult.isValid {
            self.error = validationResult.errors.first?.localizedDescription
            return
        }
        
        isLoading = true
        error = nil
        
        Task {
            do {
                let user = try await repository.login(email: email, password: password)
                await MainActor.run {
                    self.currentUser = user
                    self.isAuthenticated = true
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.error = error.localizedDescription // AuthError ya tiene descripciones localizadas
                    self.isAuthenticated = false
                    self.isLoading = false
                }
            }
        }
    }
    
    func register(username: String, email: String, password: String, confirmPassword: String = "") {
        guard let repository = repository else {
            self.error = "Servicio no disponible. Intenta más tarde."
            return
        }
        
        // Validar datos de registro
        let registrationData = RegistrationData(
            username: username,
            email: email,
            password: password,
            confirmPassword: confirmPassword.isEmpty ? password : confirmPassword
        )
        
        let validationResult = registrationValidator.validate(registrationData)
        
        if !validationResult.isValid {
            self.error = validationResult.errors.first?.localizedDescription
            return
        }
        
        isLoading = true
        error = nil
        
        Task {
            do {
                let user = try await repository.register(
                    username: username,
                    email: email,
                    password: password
                )
                
                await MainActor.run {
                    self.currentUser = user
                    self.isAuthenticated = true
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.error = error.localizedDescription // AuthError ya tiene descripciones localizadas
                    self.isLoading = false
                }
            }
        }
    }
    
    func logout() {
        guard let repository = repository else {
            return
        }
        
        isLoading = true // Indicar que se está procesando el logout
        error = nil
        
        Task {
            do {
                try await repository.logout() // Llamar al método que ahora puede lanzar errores
                await MainActor.run {
                    self.isAuthenticated = false
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    // Mostrar error específico de Keychain si es posible
                    if let authError = error as? AuthError, case .keychainError(let reason) = authError {
                        self.error = "Logout Keychain Error: \(reason)"
                    } else {
                        self.error = "Logout failed: \(error.localizedDescription)"
                    }
                    // Mantener el estado de carga en falso, pero indicar el error
                    self.isLoading = false
                    // No necesariamente cambiar isAuthenticated a false si el logout falla
                    // Podríamos dejar al usuario logueado pero mostrar el error
                }
            }
        }
    }
    
    // Otros métodos como updateProfile, etc.
}
