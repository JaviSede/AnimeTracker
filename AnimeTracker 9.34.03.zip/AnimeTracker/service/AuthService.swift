//
//  AuthService.swift
//  AnimeTracker
//
//  Created by Javi Sedeño on 28/3/25.
//  Refactored by Manus on 29/4/25.
//

import Foundation
import SwiftUI
import SwiftData

class AuthService: ObservableObject {
    @Published var currentUser: UserModel?
    @Published var isAuthenticated = false
    @Published var isLoading = false // General loading state
    @Published var error: String?
    
    private var modelContext: ModelContext?
    private let currentUserKey = "currentUserLoginID"
    
    init() {}
    
    func setModelContext(_ context: ModelContext) {
        self.modelContext = context
        loadCurrentUser()
    }
    
    func loadCurrentUser() {
        guard modelContext != nil else {
            print("AuthService: ModelContext not available yet for loading user.")
            return
        }
        if let userId = UserDefaults.standard.string(forKey: currentUserKey) {
            fetchUser(id: userId)
        } else {
            self.isAuthenticated = false
            self.currentUser = nil
        }
    }
    
    private func saveCurrentUserSession(userId: String) {
        UserDefaults.standard.set(userId, forKey: currentUserKey)
    }
    
    private func clearCurrentUserSession() {
        UserDefaults.standard.removeObject(forKey: currentUserKey)
    }
    
    func login(email: String, password: String) {
        guard let modelContext = modelContext else {
            self.error = "Database context not available. Please try again later."
            return
        }
        isLoading = true
        error = nil
        let predicate = #Predicate<UserModel> { $0.email == email }
        let descriptor = FetchDescriptor<UserModel>(predicate: predicate)
        
        // Use Task for async work, update main thread for UI changes
        Task {
            do {
                let users = try modelContext.fetch(descriptor)
                let user = users.first
                let passwordMatches = (user?.password == password) // Insecure!
                
                await MainActor.run {
                    if let validUser = user, passwordMatches {
                        self.currentUser = validUser
                        self.isAuthenticated = true
                        self.saveCurrentUserSession(userId: validUser.id)
                        print("Login successful for user: \(validUser.username)")
                    } else {
                        self.error = "Incorrect email or password."
                        self.isAuthenticated = false
                    }
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.error = "Login failed: \(error.localizedDescription)"
                    self.isAuthenticated = false
                    self.isLoading = false
                }
            }
        }
    }
    
    func register(username: String, email: String, password: String) {
        guard let modelContext = modelContext else {
            self.error = "Database context not available. Please try again later."
            return
        }
        isLoading = true
        error = nil
        
        Task {
            // 1. Check if email exists on a background thread
            let predicate = #Predicate<UserModel> { $0.email == email }
            let descriptor = FetchDescriptor<UserModel>(predicate: predicate)
            var emailExists = false
            do {
                let existingUsers = try modelContext.fetch(descriptor)
                emailExists = !existingUsers.isEmpty
            } catch {
                await MainActor.run {
                    self.error = "Error checking email: \(error.localizedDescription)"
                    self.isLoading = false
                }
                return // Stop registration if check fails
            }
            
            // If email exists, update UI and return
            if emailExists {
                await MainActor.run {
                    self.error = "This email is already registered."
                    self.isLoading = false
                }
                return
            }
            
            // 2. Create new user and stats (can be done on main thread or background)
            let newUser = UserModel(username: username, email: email, password: password)
            let stats = AnimeStats()
            newUser.stats = stats  // Establecer la relación desde el lado de UserModel
            stats.user = newUser   // Establecer la relación desde el lado de AnimeStats
            
            // 3. Insert and Save on the main context (or a background context if preferred)
            modelContext.insert(newUser)
            modelContext.insert(stats) // Asegurarse de que stats también se inserte
            
            do {
                try modelContext.save()
                await MainActor.run {
                    print("User registered successfully: \(newUser.username)")
                    // 4. Log in the new user automatically
                    self.currentUser = newUser
                    self.isAuthenticated = true
                    self.saveCurrentUserSession(userId: newUser.id)
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.error = "Registration failed: \(error.localizedDescription)"
                    self.isLoading = false
                    // Consider context rollback if needed
                    modelContext.rollback()
                }
            }
        }
    }
    
    func logout() {
        // Ensure UI updates happen on the main thread
        DispatchQueue.main.async {
            self.currentUser = nil
            self.isAuthenticated = false
            self.clearCurrentUserSession()
            print("User logged out.")
            // Reset any other necessary state
        }
    }
    
    // Updated updateProfile function
    func updateProfile(username: String, bio: String, imageData: Data?, completion: @escaping (Bool, String?) -> Void) {
        guard let modelContext = modelContext, let user = currentUser else {
            completion(false, "User not found or not logged in.")
            return
        }
        
        // Perform on a background thread to avoid blocking UI, especially if image upload were real
        Task {
            var profileImageUrl: String? = user.profileImageUrl // Keep existing URL unless new image is uploaded
            var uploadError: String? = nil

            // --- Placeholder Image Upload Logic --- 
            if let data = imageData {
                print("Simulating image upload for data of size \(data.count) bytes...")
                // In a real app: Upload `data` to cloud storage (e.g., Firebase Storage, S3)
                // let uploadedUrl = await uploadToCloudStorage(data: data)
                // For now, simulate success with a placeholder URL or identifier
                // To make it visually change, we can use a timestamp or random string
                let simulatedUrl = "https://placeholder.com/simulated-upload/\(UUID().uuidString).jpg"
                profileImageUrl = simulatedUrl
                print("Simulated upload complete. URL: \(simulatedUrl)")
                // Handle potential upload errors from the real function
                // if uploadFailed { uploadError = "Failed to upload image." }
            }
            // --- End Placeholder --- 

            // If image upload failed (in a real scenario), stop before saving other changes
            if let uploadError = uploadError {
                await MainActor.run {
                    completion(false, uploadError)
                }
                return
            }

            // Check if there are actual changes to save
            let didChange = user.username != username || user.bio != bio || user.profileImageUrl != profileImageUrl

            if !didChange {
                print("No profile changes detected.")
                await MainActor.run {
                    completion(true, nil) // Report success as no action was needed
                }
                return
            }

            // Apply changes to the user object (must be done on the context's thread/actor)
            user.username = username
            user.bio = bio
            user.profileImageUrl = profileImageUrl

            // Save changes
            do {
                // Ensure save happens on the correct context/thread
                try modelContext.save()
                print("Profile updated successfully for user: \(user.username)")
                // Notify UI on the main thread
                await MainActor.run {
                    // Manually trigger update for currentUser if needed, though @Published should handle it
                    // self.objectWillChange.send()
                    completion(true, nil)
                }
            } catch {
                let errorDesc = "Failed to save profile update: \(error.localizedDescription)"
                print(errorDesc)
                // Optionally rollback context
                // modelContext.rollback()
                await MainActor.run {
                    completion(false, errorDesc)
                }
            }
        }
    }
    
    private func fetchUser(id: String) {
        guard let modelContext = modelContext else {
            print("FetchUser failed: ModelContext not available.")
            DispatchQueue.main.async {
                self.isAuthenticated = false
                self.currentUser = nil
            }
            return
        }
        
        let predicate = #Predicate<UserModel> { $0.id == id }
        let descriptor = FetchDescriptor<UserModel>(predicate: predicate)
        
        // Perform fetch potentially on background, update UI on main
        Task {
            do {
                let users = try modelContext.fetch(descriptor)
                let user = users.first
                
                await MainActor.run {
                    if let validUser = user {
                        self.currentUser = validUser
                        self.isAuthenticated = true
                        print("Successfully fetched and set current user: \(validUser.username)")
                    } else {
                        print("User ID \(id) found in session, but no matching user in database.")
                        self.logout() // Log out to clear inconsistent state
                    }
                }
            } catch {
                print("Error fetching user with ID \(id): \(error.localizedDescription)")
                await MainActor.run {
                    self.logout() // Log out on error
                }
            }
        }
    }
}

