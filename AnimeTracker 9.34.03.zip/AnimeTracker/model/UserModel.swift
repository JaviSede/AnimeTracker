//
//  UserModel.swift // Contains AnimeStats model
//  AnimeTracker
//
//  Created by Javi Sedeño on 28/3/25.
//  Updated by Manus on 29/4/25 to add recalculate method.
//

import Foundation
import SwiftData

@Model
final class UserModel {
    @Attribute(.unique) var id: String // Ensure ID is unique
    var username: String
    @Attribute(.unique) var email: String // Ensure email is unique
    var profileImageUrl: String?
    var bio: String?
    var joinDate: Date
    var password: String // WARNING: In production, use secure hashing and storage methods

    // Relationships
    // Cascade ensures stats are deleted if user is deleted
    // Inverse relationship helps SwiftData manage the connection
    @Relationship(deleteRule: .cascade, inverse: \AnimeStats.user)
    var stats: AnimeStats?

    // Cascade ensures saved animes are deleted if user is deleted
    @Relationship(deleteRule: .cascade, inverse: \SavedAnimeModel.user)
    var savedAnimes: [SavedAnimeModel] = []

    init(id: String = UUID().uuidString,
         username: String,
         email: String,
         profileImageUrl: String? = nil,
         bio: String? = nil,
         password: String) {
        self.id = id
        self.username = username
        self.email = email
        self.profileImageUrl = profileImageUrl
        self.bio = bio
        self.joinDate = Date()
        self.password = password
        // Initializing stats here can be problematic with SwiftData relationships
        // It's better to create and assign stats during registration or lazily
        // self.stats = AnimeStats() // Removed from here
        self.savedAnimes = []
    }
}

@Model
final class AnimeStats {
    // Stats properties
    var totalAnime: Int = 0
    var watching: Int = 0
    var completed: Int = 0
    var planToWatch: Int = 0  // Corregido de planToWatchCount a planToWatch
    var onHold: Int = 0
    var dropped: Int = 0
    var totalEpisodes: Int = 0
    var daysWatched: Double = 0.0

    // Relationship back to the user (owning side)
    // Optional because a Stats object might briefly exist before being assigned
    @Relationship(inverse: \UserModel.stats)
    var user: UserModel?

    // Default initializer
    init() {}

    // Method to recalculate all statistics based on a list of SavedAnimeModel
    func recalculate(from animes: [SavedAnimeModel]) {
        // Reset counts before recalculating
        watching = 0
        completed = 0
        planToWatch = 0  // Actualizado aquí también
        onHold = 0
        dropped = 0
        totalEpisodes = 0
        // totalAnime is simply the count of the list
        totalAnime = animes.count

        // Iterate through the provided anime list
        for anime in animes {
            // Increment status counts
            switch anime.status {
            case .watching:
                watching += 1
            case .completed:
                completed += 1
            case .planToWatch:
                planToWatch += 1  // Actualizado aquí también
            case .onHold:
                onHold += 1
            case .dropped:
                dropped += 1
            }
            // Sum up the current episode count for all animes
            // Note: This interpretation might differ based on requirements.
            // Should it be only completed/watching episodes? Assuming all for now.
            totalEpisodes += anime.currentEpisode
        }

        // Calculate days watched (assuming 24 minutes per episode)
        let totalMinutes = Double(totalEpisodes) * 24.0
        // Avoid division by zero if totalMinutes is 0
        daysWatched = totalMinutes > 0 ? totalMinutes / (60.0 * 24.0) : 0.0
        
        print("Stats recalculated: Total=\(totalAnime), Watching=\(watching), Completed=\(completed), Plan=\(planToWatch), Hold=\(onHold), Dropped=\(dropped), Episodes=\(totalEpisodes), Days=\(String(format: "%.1f", daysWatched))")
    }
}

